"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import type { User } from "@supabase/supabase-js";
import { BarChart, DonutChart, LineChart } from "@/components/charts";
import {
  academicYears,
  getYear,
  termLabel,
  type TermNumber,
  yearLabel,
} from "@/lib/calendar";
import TeacherDashboard from "@/components/teacher-dashboard";
import ProfilePanel from "@/components/profile-panel";
import PromotionPanel from "@/components/promotion-panel";
import LessonPlansView from "@/components/lesson-plans-view";
import { StatCardSkeleton, PanelSkeleton, Spinner } from "@/components/loading";

function PageLoading() {
  return <div className="me-loading"><Spinner size={20} /></div>;
}

const ClassManagement = dynamic(() => import("@/components/class-management"), { ssr: false, loading: PageLoading });
const SubjectManagement = dynamic(() => import("@/components/subject-management"), { ssr: false, loading: PageLoading });
const StudentsManagement = dynamic(() => import("@/components/students-management"), { ssr: false, loading: PageLoading });
const StudentLogins = dynamic(() => import("@/components/student-logins"), { ssr: false, loading: PageLoading });
const TeachersManagement = dynamic(() => import("@/components/teachers-management"), { ssr: false, loading: PageLoading });
const SubjectAnalysis = dynamic(() => import("@/components/subject-analysis"), { ssr: false, loading: PageLoading });
const ExamManagement = dynamic(() => import("@/components/exam-management"), { ssr: false, loading: PageLoading });
const ExamAttendance = dynamic(() => import("@/components/exam-attendance"), { ssr: false, loading: PageLoading });
const ResultPage = dynamic(() => import("@/components/result-page"), { ssr: false, loading: PageLoading });
const StudentReportCard = dynamic(() => import("@/components/student-report-card"), { ssr: false, loading: PageLoading });
const CompareResults = dynamic(() => import("@/components/compare-results"), { ssr: false, loading: PageLoading });
const BestStudentYearly = dynamic(() => import("@/components/best-student-yearly"), { ssr: false, loading: PageLoading });
const AwardCertificates = dynamic(() => import("@/components/award-certificates"), { ssr: false, loading: PageLoading });
const CombinedResults = dynamic(() => import("@/components/combined-results"), { ssr: false, loading: PageLoading });
const SmsMessaging = dynamic(() => import("@/components/sms-messaging"), { ssr: false, loading: PageLoading });
const StudentEnrollmentStatistics = dynamic(() => import("@/components/student-enrollment-statistics"), { ssr: false, loading: PageLoading });
const StreamTeacherAssignment = dynamic(() => import("@/components/stream-teacher-assignment"), { ssr: false, loading: PageLoading });
const MkondoWangu = dynamic(() => import("@/components/mkondo-wangu"), { ssr: false, loading: PageLoading });
const TimetableView = dynamic(() => import("@/components/timetable/timetable-view"), { ssr: false, loading: PageLoading });
const TeacherAssignments = dynamic(() => import("@/components/teacher-assignments"), { ssr: false, loading: PageLoading });
const TeacherStudyNotes = dynamic(() => import("@/components/teacher-study-notes"), { ssr: false, loading: PageLoading });
import type { TimetableSection } from "@/components/timetable/timetable-view";
import { fetchAcademicSettings, fetchDashboardData, fetchSchoolInfo, fetchWhatsappLinks, saveAcademicSettings, saveSchoolInfo, saveWhatsappLinks, type DashboardData, type SchoolInfo, type WhatsappLinks } from "@/lib/school-api";
import { DEFAULT_SCHOOL_INFO, DEFAULT_WHATSAPP_LINKS } from "@/lib/school-api";
import { readStoredJson, readStoredPeriod, writeStoredJson, writeStoredPeriod, type StoredPeriod } from "@/lib/preferences";
import { errorMessage } from "@/lib/errors";
import Sidebar from "@/components/navigation/sidebar";
import Breadcrumbs from "@/components/navigation/breadcrumbs";
import NotificationBell from "@/components/notification-bell";
import type { NotificationTarget } from "@/lib/notifications-types";
import {
  allowedKeysFor,
  breadcrumbsFor,
  isNavKey,
  resolveRole,
  roleLabels,
  visibleMenuFor,
  type NavKey,
} from "@/components/navigation/nav-config";
import { fetchStreamTeacherMe, type StreamTeacherAssignment as StreamTeacherRecord } from "@/lib/stream-teacher-api";
import type { StreamTeacherSection } from "@/components/mkondo-wangu";

type IconProps = { paths: React.ReactNode };

function Icon({ paths }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="icon" aria-hidden="true">
      {paths}
    </svg>
  );
}

const icons = {
  dashboard: <Icon paths={<><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /></>} />,
  students: <Icon paths={<><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></>} />,
  staff: <Icon paths={<><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="m16 11 2 2 4-4" /></>} />,
  classes: <Icon paths={<><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" /></>} />,
  academic: <Icon paths={<><path d="M22 10v6" /><path d="M2 10 12 5l10 5-10 5z" /><path d="M6 12v5c3 3 9 3 12 0v-5" /></>} />,
  reports: <Icon paths={<><line x1="12" y1="20" x2="12" y2="10" /><line x1="18" y1="20" x2="18" y2="4" /><line x1="6" y1="20" x2="6" y2="16" /></>} />,
  reportcard: <Icon paths={<><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" /><path d="M14 2v6h6" /><path d="M9 13h6" /><path d="M9 17h6" /></>} />,
  compare: <Icon paths={<><path d="M8 3v9" /><path d="M4 12h8v9H4z" /><path d="M16 3h4v9h-4z" /><path d="M16 16h4v5h-4z" /></>} />,
  combined: <Icon paths={<><path d="M12 2 2 7l10 5 10-5-10-5Z" /><path d="m2 12 10 5 10-5" /><path d="m2 17 10 5 10-5" /></>} />,
  analysis: <Icon paths={<><path d="M3 3v18h18" /><rect x="7" y="10" width="3" height="8" /><rect x="12" y="6" width="3" height="12" /><rect x="17" y="13" width="3" height="5" /></>} />,
  exams: <Icon paths={<><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" /><rect x="9" y="3" width="6" height="4" rx="1" /><path d="m9 14 2 2 4-4" /></>} />,
  attendance: <Icon paths={<><rect x="3" y="4" width="18" height="17" rx="2" /><path d="M8 2v4" /><path d="M16 2v4" /><path d="M3 10h18" /><path d="m9 15 1.6 1.6L14 13" /></>} />,
  lessonplans: <Icon paths={<><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" /><path d="M9 7h6" /><path d="M9 11h4" /></>} />,
  settings: <Icon paths={<><circle cx="12" cy="12" r="3" /><path d="M12 2h1v3" /><path d="M12 19v3" /><path d="M2 12h3" /><path d="M19 12h3" /></>} />,
  bell: <Icon paths={<><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" /></>} />,
  logout: <Icon paths={<><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="m16 17 5-5-5-5" /><line x1="21" y1="12" x2="9" y2="12" /></>} />,
  menu: <Icon paths={<><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" /></>} />,
  close: <Icon paths={<><path d="M18 6 6 18" /><path d="m6 6 12 12" /></>} />,
  chevron: <Icon paths={<><path d="m6 9 6 6 6-6" /></>} />,
  trendUp: <Icon paths={<><path d="m22 7-8.5 8.5-5-5L2 17" /><path d="M16 7h6v6" /></>} />,
  trendDown: <Icon paths={<><path d="m22 17-8.5-8.5-5 5L2 7" /><path d="M16 17h6v-6" /></>} />,
  check: <Icon paths={<><path d="M20 6 9 17l-5-5" /></>} />,
};

type Period = StoredPeriod;

function loadStoredPeriod(): Period {
  return readStoredPeriod();
}

function persistPeriod(period: Period) {
  writeStoredPeriod(period);
}

export default function Dashboard({
  user,
  onLogout,
  loggingOut = false,
}: {
  user: User;
  onLogout: () => void;
  loggingOut?: boolean;
}) {
  const role = resolveRole(user.user_metadata?.role);
  const navigationKey = `active-nav:${user.id}`;
  const [active, setActive] = useState<NavKey>(() =>
    readStoredJson<NavKey>(navigationKey, "dashboard", isNavKey)
  );
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(() => {
    const current = readStoredJson<NavKey>(navigationKey, "dashboard", isNavKey);
    return (
      visibleMenuFor(role).find(
        (entry) => entry.kind === "group" && entry.items.some((item) => item.key === current),
      )?.key ?? null
    );
  });
  const [profileOpen, setProfileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [accountTab, setAccountTab] = useState<"profile" | "password">("profile");
  const [profileDraft, setProfileDraft] = useState<{ name: string; phone: string } | null>(null);
  const [activePeriod, setActivePeriod] = useState<Period>(loadStoredPeriod);
  const [viewPeriod, setViewPeriod] = useState<Period>(loadStoredPeriod);
  const [streamAssignments, setStreamAssignments] = useState<StreamTeacherRecord[]>([]);
  const [selectedStreamId, setSelectedStreamId] = useState("");
  const [assignmentLink, setAssignmentLink] = useState<{
    assignmentId: string;
    submissionId?: string;
  } | null>(null);
  const [studentLoginFocusId, setStudentLoginFocusId] = useState<string | null>(null);

  useEffect(() => {
    if (role !== "Teacher") return;
    let activeRequest = true;
    fetchStreamTeacherMe()
      .then((result) => {
        if (!activeRequest) return;
        setStreamAssignments(result.assignments);
        const forYear = result.assignments.filter((item) => item.academic_year_id === activePeriod.yearId);
        setSelectedStreamId((current) =>
          forYear.some((item) => item.stream_id === current) ? current : (forYear[0]?.stream_id ?? ""),
        );
      })
      .catch(() => {
        if (activeRequest) setStreamAssignments([]);
      });
    return () => {
      activeRequest = false;
    };
  }, [role, activePeriod.yearId]);

  useEffect(() => {
    fetchAcademicSettings()
      .then((settings) => {
        if (!settings) return;
        const period: Period = { yearId: settings.activeYearId, term: settings.activeTerm };
        if (!academicYears.some((year) => year.id === period.yearId)) return;
        setActivePeriod(period);
        setViewPeriod(period);
        persistPeriod(period);
      })
      .catch(() => {
        // DB unavailable - keep localStorage period
      });
  }, []);

  const yearStreamAssignments = streamAssignments.filter(
    (assignment) => assignment.academic_year_id === activePeriod.yearId,
  );
  const hasStreamTeacher = role === "Teacher" && yearStreamAssignments.length > 0;
  const allowedKeys = allowedKeysFor(role, { hasStreamTeacher });
  const menuEntries = visibleMenuFor(role, { hasStreamTeacher });
  const notificationTargets: NotificationTarget[] = allowedKeys.includes("assignments")
    ? ["studentlogins", "assignments"]
    : ["studentlogins"];
  const effectiveActive: NavKey = allowedKeys.includes(active) ? active : "dashboard";
  const streamSection: StreamTeacherSection | null =
    effectiveActive === "streamstudents"
      ? "students"
      : effectiveActive === "streamsubjects"
        ? "subjects"
        : effectiveActive === "streamresults"
          ? "results"
          : effectiveActive === "streamreports"
            ? "reports"
            : effectiveActive === "streambeststudent"
              ? "beststudent"
              : effectiveActive === "streamcertificates"
                ? "certificates"
                : null;
  const timetableSection: TimetableSection | null =
    effectiveActive === "ttsetup"
      ? "setup"
      : effectiveActive === "ttperiods"
        ? "periods"
        : effectiveActive === "ttrules"
          ? "rules"
          : effectiveActive === "ttgenerate"
            ? "generate"
            : effectiveActive === "tttimetables"
              ? "timetables"
              : null;
  const wideContent = streamSection === "results" || timetableSection !== null;
  const crumbs = breadcrumbsFor(effectiveActive, menuEntries);
  const displayName =
    profileDraft?.name?.trim() ||
    ((user.user_metadata?.name as string) ?? "").trim() ||
    (user.email ? user.email.split("@")[0] : "User");
  const initials = displayName.slice(0, 2).toUpperCase();

  function openAccount(tab: "profile" | "password") {
    setProfileOpen(false);
    setAccountTab(tab);
    setAccountOpen(true);
  }
  function pickNav(key: NavKey) {
    if (!allowedKeys.includes(key)) return;
    setActive(key);
    const group = menuEntries.find(
      (entry) => entry.kind === "group" && entry.items.some((item) => item.key === key),
    );
    if (group) setOpenGroup(group.key);
    writeStoredJson(navigationKey, key);
    setSidebarOpen(false);
  }

  function toggleGroup(key: string) {
    setOpenGroup((current) => (current === key ? null : key));
  }

  function applyPeriod(period: Period) {
    setActivePeriod(period);
    setViewPeriod(period);
    persistPeriod(period);
    saveAcademicSettings({ activeYearId: period.yearId, activeTerm: period.term }).catch(() => {
      // DB unavailable - period saved in localStorage only
    });
  }

  return (
    <div className="app-shell">
      {sidebarOpen && <div className="backdrop" onClick={() => setSidebarOpen(false)} />}

      <Sidebar
        role={role}
        active={effectiveActive}
        openGroup={openGroup}
        mobileOpen={sidebarOpen}
        onSelect={pickNav}
        onOpenGroup={toggleGroup}
        onCloseMobile={() => setSidebarOpen(false)}
        storageKey={user.id}
        hasStreamTeacher={hasStreamTeacher}
      />

      <div className="app-main">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-btn menu-toggle" onClick={() => setSidebarOpen(true)} aria-label="Open menu">{icons.menu}</button>
            <Breadcrumbs items={crumbs} onNavigate={pickNav} />
          </div>

          <div className="topbar-right">
            {role === "Academic" || role === "Headmaster" ? (
              <NotificationBell
                userId={user.id}
                allowedTargets={notificationTargets}
                onNavigate={(target, notification) => {
                  pickNav(target);
                  if (target === "assignments") {
                    setAssignmentLink(
                      notification.assignmentId
                        ? {
                            assignmentId: notification.assignmentId,
                            submissionId: notification.submissionId,
                          }
                        : null,
                    );
                  }
                  if (target === "studentlogins") {
                    setStudentLoginFocusId(notification.studentId ?? null);
                  }
                }}
              />
            ) : (
              <button className="icon-btn" aria-label="Notifications">{icons.bell}</button>
            )}
            <button className="logout-btn" onClick={onLogout} disabled={loggingOut}>
              {loggingOut ? <span className="spinner" aria-hidden="true" /> : icons.logout}
              <span>{loggingOut ? "Signing out…" : "Log out"}</span>
            </button>
            <div className="profile-wrap">
              <button className="profile-btn" onClick={() => setProfileOpen((v) => !v)} aria-haspopup="menu" aria-expanded={profileOpen}>
                <div className="avatar">{initials}</div>
                <div className="profile-meta">
                  <div className="profile-name">{displayName}</div>
                  <div className="profile-role">{roleLabels[role]}</div>
                </div>
                {icons.chevron}
              </button>
              {profileOpen && (
                <>
                  <div className="profile-backdrop" onClick={() => setProfileOpen(false)} />
                  <div className="dropdown" role="menu">
                    <div className="dropdown-head">
                      <div className="avatar">{initials}</div>
                      <div>
                        <div className="dropdown-name">{displayName}</div>
                        <div className="dropdown-email">{user.email ?? roleLabels[role]}</div>
                      </div>
                    </div>
                    <div className="dropdown-divider" />
                    <button className="dropdown-item" onClick={() => openAccount("profile")}>Profile</button>
                    <button className="dropdown-item" onClick={() => openAccount("password")}>Change password</button>
                    {allowedKeys.includes("settings") && (
                      <button className="dropdown-item" onClick={() => pickNav("settings")}>Settings</button>
                    )}
                    <button className="dropdown-item dropdown-item--danger" onClick={onLogout} disabled={loggingOut}>
                      {loggingOut ? <span className="spinner" aria-hidden="true" /> : icons.logout}
                      <span>{loggingOut ? "Signing out…" : "Log out"}</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        <main className={wideContent ? "content content--wide" : "content"}>
          {effectiveActive === "dashboard" && (role === "Teacher" ? (
            <TeacherDashboard
              authUserId={user.id}
              onNavigate={(key) => { if (isNavKey(key)) pickNav(key); }}
              quickLinks={menuEntries
                .flatMap((entry) => (entry.kind === "group" ? entry.items : [entry]))
                .filter((item) => item.key !== "dashboard")}
            />
          ) : (
            <DashboardView
              period={viewPeriod}
              onPeriod={setViewPeriod}
              activePeriod={activePeriod}
            />
          ))}
          {effectiveActive === "settings" && (
            <SettingsPanel active={activePeriod} onSave={applyPeriod} />
          )}
          {effectiveActive === "classes" && <ClassManagement />}
          {effectiveActive === "academic" && <SubjectManagement />}
          {effectiveActive === "students" && <StudentsManagement />}
          {effectiveActive === "studentlogins" && (
            <StudentLogins
              focusStudentId={studentLoginFocusId}
              onFocusConsumed={() => setStudentLoginFocusId(null)}
            />
          )}
          {effectiveActive === "staff" && <TeachersManagement currentUserId={user.id} />}
          {effectiveActive === "streamteachers" && <StreamTeacherAssignment year={activePeriod.yearId} />}
          {streamSection && (
            <MkondoWangu
              section={streamSection}
              assignments={yearStreamAssignments}
              selectedStreamId={selectedStreamId}
              onSelectStream={setSelectedStreamId}
              year={activePeriod.yearId}
              term={activePeriod.term}
            />
          )}
          {effectiveActive === "exams" && <ExamManagement teacherId={role === "Teacher" ? user.id : undefined} role={role} />}
          {effectiveActive === "attendance" && <ExamAttendance teacherId={role === "Teacher" ? user.id : undefined} />}
          {effectiveActive === "reports" && <ResultPage role={role} />}
          {effectiveActive === "analysis" && <SubjectAnalysis authUserId={user.id} />}
          {effectiveActive === "enrollment" && <StudentEnrollmentStatistics />}
          {effectiveActive === "reportcard" && <StudentReportCard role={role} />}
          {effectiveActive === "compare" && <CompareResults role={role} teacherId={role === "Teacher" ? user.id : undefined} />}
          {effectiveActive === "combined" && <CombinedResults />}
          {effectiveActive === "beststudent" && <BestStudentYearly />}
          {effectiveActive === "certificates" && <AwardCertificates />}
          {effectiveActive === "sms" && <SmsMessaging />}
          {effectiveActive === "lessonplans" && <LessonPlansView />}
          {effectiveActive === "assignments" && (role === "Teacher" || role === "Academic") && (
            <TeacherAssignments
              initialTarget={assignmentLink}
              onInitialTargetConsumed={() => setAssignmentLink(null)}
            />
          )}
          {effectiveActive === "notes" && (role === "Teacher" || role === "Academic") && <TeacherStudyNotes />}
          {timetableSection && (
            <TimetableView
              section={timetableSection}
              role={role}
              year={activePeriod.yearId}
              term={activePeriod.term}
              onShowTimetable={() => pickNav("tttimetables")}
            />
          )}
        </main>
      </div>
      {accountOpen && (
        <ProfilePanel
          user={user}
          roleLabel={roleLabels[role]}
          initialTab={accountTab}
          onClose={() => setAccountOpen(false)}
          onSaved={(data) => setProfileDraft(data)}
        />
      )}
    </div>
  );
}

function DashboardView({
  period,
  onPeriod,
  activePeriod,
}: {
  period: Period;
  onPeriod: (period: Period) => void;
  activePeriod: Period;
}) {
  const { yearId, term } = period;
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [dbError, setDbError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setDbError(null);
      try {
        const result = await fetchDashboardData(yearId, term);
        if (!cancelled) setData(result);
      } catch (err: unknown) {
        if (!cancelled) {
          setData(null);
          setDbError(errorMessage(err, "Failed to load dashboard data"));
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [yearId, term]);

  const terms = getYear(yearId).terms;
  const isActive = activePeriod.yearId === yearId && activePeriod.term === term;

  if (loading) {
    return (
      <>
        <div className="page-head">
          <div>
            <h2 className="page-title">School Overview</h2>
            <p className="page-sub">Summary and key metrics for {termLabel(term)} of {yearLabel(yearId)}.</p>
          </div>
          <div className="page-head-right">
            {isActive && <span className="active-chip">● Active</span>}
            <PeriodPicker
              yearId={yearId}
              term={term}
              terms={terms}
              onYear={(year) => onPeriod({ ...period, yearId: year })}
              onTerm={(nextTerm) => onPeriod({ ...period, term: nextTerm })}
            />
          </div>
        </div>
        <div className="stats-grid">
          <StatCardSkeleton />
          <StatCardSkeleton />
          <StatCardSkeleton />
          <StatCardSkeleton />
        </div>
        <div className="section-grid">
          <PanelSkeleton lines={5} />
          <PanelSkeleton lines={4} />
        </div>
      </>
    );
  }

  if (dbError || !data) {
    return (
      <>
        <div className="page-head">
          <div>
            <h2 className="page-title">School Overview</h2>
            <p className="page-sub">Summary and key metrics for {termLabel(term)} of {yearLabel(yearId)}.</p>
          </div>
          <div className="page-head-right">
            {isActive && <span className="active-chip">● Active</span>}
          </div>
        </div>
        <div className="db-empty">
          <h3>Dashboard data not ready</h3>
          <p>Could not read data from the database. Make sure the tables exist and have been seeded.</p>
          <pre className="db-error">{dbError}</pre>
        </div>
      </>
    );
  }

  const avgScore = data.avgPerformance;
  const stats = [
    { label: "Total Students", value: data.totalStudents.toLocaleString(), change: null, up: true, icon: icons.students },
    { label: "Teaching Staff", value: data.teachingStaff.toLocaleString(), change: null, up: true, icon: icons.staff },
    { label: "Active Classes", value: data.activeClasses.toLocaleString(), change: null, up: true, icon: icons.classes },
    { label: "Avg Performance", value: `${avgScore}%`, change: null, up: true, icon: icons.academic },
  ];

  return (
    <>
      <div className="page-head">
        <div>
          <h2 className="page-title">School Overview</h2>
          <p className="page-sub">Summary and key metrics for {termLabel(term)} of {yearLabel(yearId)}.</p>
        </div>
        <div className="page-head-right">
          {isActive && <span className="active-chip">● Active</span>}
          <PeriodPicker
            yearId={yearId}
            term={term}
            terms={terms}
            onYear={(year) => onPeriod({ ...period, yearId: year })}
            onTerm={(nextTerm) => onPeriod({ ...period, term: nextTerm })}
          />
        </div>
      </div>

      <div className="stats-grid">
        {stats.map((s) => (
          <div className="stat-card" key={s.label}>
            <div className="stat-top">
              <span className="stat-icon">{s.icon}</span>
            </div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="section-grid">
        <div className="panel">
          <div className="panel-head">
            <div>
              <h3 className="panel-title">Student Attendance</h3>
              <p className="panel-sub">Share of {yearLabel(yearId)} exam sittings attended, by class</p>
            </div>
            <span className="panel-badge">By class</span>
          </div>
          <BarChart data={data.attendance} highlight={3} />
        </div>

        <div className="panel">
          <div className="panel-head">
            <div>
              <h3 className="panel-title">Student Distribution</h3>
              <p className="panel-sub">By gender</p>
            </div>
          </div>
          <div className="donut-wrap">
            <DonutChart
              centerTop={data.totalStudents.toLocaleString()}
              centerBottom="Students"
              segments={[
                { label: "Boys", value: data.genderDistribution[0]?.value ?? 0, color: "#6d28d9" },
                { label: "Girls", value: data.genderDistribution[1]?.value ?? 0, color: "#d4af37" },
              ]}
            />
          </div>
          <div className="legend">
            {data.genderDistribution.map((item, i) => (
              <div className="legend-item" key={item.label}>
                <span className={`legend-dot legend-dot--${i}`} />
                <span>{item.label}</span>
                <strong>{item.value}%</strong>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="section-grid section-grid--alt">
        <div className="panel">
          <div className="panel-head">
            <div>
              <h3 className="panel-title">Performance Trend</h3>
              <p className="panel-sub">Mean score per term in {yearLabel(yearId)}</p>
            </div>
            <span className="panel-badge">{yearLabel(yearId)}</span>
          </div>
          <LineChart points={data.performanceTrend} />
        </div>

        <div className="panel">
          <div className="panel-head">
            <div>
              <h3 className="panel-title">Subject Performance</h3>
              <p className="panel-sub">Mean score per subject · {termLabel(term)} {yearLabel(yearId)}</p>
            </div>
          </div>
          <div className="subject-table-wrap">
            <table className="subject-table">
            <thead>
              <tr>
                <th>Subject</th>
                <th>Class</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {data.subjectPerformance.length === 0 && (
                <tr>
                  <td colSpan={3} className="subject-empty">No exam marks recorded for this period yet.</td>
                </tr>
              )}
              {data.subjectPerformance.map((row) => (
                <tr key={row.subject}>
                  <td><div className="subject-name">{row.subject}</div><div className="subject-class">{row.class}</div></td>
                  <td>
                    <div className="score-bar">
                      <div className={`score-bar-fill${row.score >= 80 ? " score-bar-fill--good" : row.score >= 75 ? " score-bar-fill--mid" : " score-bar-fill--low"}`} style={{ width: `${row.score}%` }} />
                    </div>
                    <div className="score-value">
                      <strong>{row.score}%</strong>
                      <span className={row.up ? "trend trend--up" : "trend trend--down"}>{row.up ? "▲" : "▼"}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      </div>
    </>
  );
}

function PeriodPicker({
  yearId,
  term,
  terms,
  onYear,
  onTerm,
}: {
  yearId: string;
  term: TermNumber;
  terms: TermNumber[];
  onYear: (year: string) => void;
  onTerm: (term: TermNumber) => void;
}) {
  return (
    <div className="period-picker">
      <label className="period-picker-label">
        <span>Academic Year</span>
        <select className="period-select" value={yearId} onChange={(event) => onYear(event.target.value)}>
          {academicYears.map((year) => (
            <option key={year.id} value={year.id}>{year.label}</option>
          ))}
        </select>
      </label>
      <label className="period-picker-label">
        <span>Term</span>
        <select className="period-select" value={term} onChange={(event) => onTerm(Number(event.target.value) as TermNumber)}>
          {terms.map((t) => (
            <option key={t} value={t}>{termLabel(t)}</option>
          ))}
        </select>
      </label>
    </div>
  );
}

function SettingsPanel({ active, onSave }: { active: Period; onSave: (period: Period) => void }) {
  const [yearId, setYearId] = useState(active.yearId);
  const [term, setTerm] = useState<TermNumber>(active.term);
  const [saved, setSaved] = useState(false);
  const dirty = yearId !== active.yearId || term !== active.term;
  const terms = getYear(yearId).terms;

  useEffect(() => {
    setYearId(active.yearId);
    setTerm(active.term);
  }, [active.yearId, active.term]);

  const [school, setSchool] = useState<SchoolInfo>(DEFAULT_SCHOOL_INFO);
  const [savedSchool, setSavedSchool] = useState<SchoolInfo>(DEFAULT_SCHOOL_INFO);
  const [schoolLoading, setSchoolLoading] = useState(true);
  const [schoolSaved, setSchoolSaved] = useState(false);
  const [schoolError, setSchoolError] = useState("");

  useEffect(() => {
    let activePanel = true;
    fetchSchoolInfo()
      .then((info) => {
        setSchool(info);
        setSavedSchool(info);
      })
      .catch(() => {
        if (activePanel) setSchoolError("Could not load school information.");
      })
      .finally(() => activePanel && setSchoolLoading(false));
    return () => {
      activePanel = false;
    };
  }, []);

  const schoolDirty =
    school.name !== savedSchool.name ||
    school.council !== savedSchool.council ||
    school.district !== savedSchool.district ||
    school.address !== savedSchool.address ||
    school.unionLogo !== savedSchool.unionLogo ||
    school.schoolLogo !== savedSchool.schoolLogo;

  async function handleSchoolSave() {
    if (!schoolDirty) return;
    setSchoolError("");
    try {
      await saveSchoolInfo(school);
      setSavedSchool(school);
      setSchoolSaved(true);
      window.setTimeout(() => setSchoolSaved(false), 2500);
    } catch {
      setSchoolError("Could not save school information.");
    }

  }

  function handleLogoChange(field: "unionLogo" | "schoolLogo", file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setSchoolError("Please select an image file for the logo.");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setSchoolError("Each logo must be 2 MB or smaller.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setSchool((current) => ({ ...current, [field]: reader.result }));
        setSchoolError("");
      }
    };
    reader.onerror = () => setSchoolError("Could not read the selected logo.");
    reader.readAsDataURL(file);
  }

  const [whatsapp, setWhatsapp] = useState<WhatsappLinks>(DEFAULT_WHATSAPP_LINKS);
  const [savedWhatsapp, setSavedWhatsapp] = useState<WhatsappLinks>(DEFAULT_WHATSAPP_LINKS);
  const [whatsappLoading, setWhatsappLoading] = useState(true);
  const [whatsappSaved, setWhatsappSaved] = useState(false);
  const [whatsappError, setWhatsappError] = useState("");

  useEffect(() => {
    let activePanel = true;
    fetchWhatsappLinks()
      .then((links) => {
        if (!activePanel) return;
        setWhatsapp(links);
        setSavedWhatsapp(links);
      })
      .catch(() => {
        if (activePanel) setWhatsappError("Could not load WhatsApp links.");
      })
      .finally(() => activePanel && setWhatsappLoading(false));
    return () => {
      activePanel = false;
    };
  }, []);

  const whatsappDirty = whatsapp.results !== savedWhatsapp.results || whatsapp.parentsGroup !== savedWhatsapp.parentsGroup;

  async function handleWhatsappSave() {
    if (!whatsappDirty) return;
    const trimmed = { results: whatsapp.results.trim(), parentsGroup: whatsapp.parentsGroup.trim() };
    for (const link of [trimmed.results, trimmed.parentsGroup]) {
      if (link && !/^https?:\/\//i.test(link)) {
        setWhatsappError("Each link must start with http:// or https:// — or leave it empty to leave it out of the SMS.");
        return;
      }
    }
    setWhatsappError("");
    try {
      await saveWhatsappLinks(trimmed);
      setWhatsapp(trimmed);
      setSavedWhatsapp(trimmed);
      setWhatsappSaved(true);
      window.setTimeout(() => setWhatsappSaved(false), 2500);
    } catch {
      setWhatsappError("Could not save WhatsApp links.");
    }
  }

  function handleSave() {
    if (!dirty) return;
    onSave({ yearId, term });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h2 className="page-title">Settings</h2>
          <p className="page-sub">Manage your school portal configuration.</p>
        </div>
        <span className="active-chip">● Active: {termLabel(active.term)} · {yearLabel(active.yearId)}</span>
      </div>

      <div className="settings-card">
        <div className="panel-head">
          <div>
            <h3 className="panel-title">Academic Calendar</h3>
            <p className="panel-sub">Set the Active Academic Year and Active Term used across the portal.</p>
          </div>
        </div>

        <div className="settings-form">
          <label className="settings-field">
            <span className="settings-field-label">Active Academic Year</span>
            <select className="settings-select" value={yearId} onChange={(event) => setYearId(event.target.value)}>
              {academicYears.map((year) => (
                <option key={year.id} value={year.id}>{year.label}</option>
              ))}
            </select>
          </label>
          <label className="settings-field">
            <span className="settings-field-label">Active Term</span>
            <select className="settings-select" value={term} onChange={(event) => setTerm(Number(event.target.value) as TermNumber)}>
              {terms.map((t) => (
                <option key={t} value={t}>{termLabel(t)}</option>
              ))}
            </select>
          </label>
        </div>

        <div className="settings-actions">
          <span className={`settings-status${saved ? " settings-status--ok" : ""}`}>
            {saved ? "Saved" : dirty ? "Unsaved changes" : "Up to date"}
          </span>
          <button className="settings-save" onClick={handleSave} disabled={!dirty}>
            {icons.check}<span>Save changes</span>
          </button>
        </div>
      </div>

      <PromotionPanel
        activeYear={active.yearId}
        onPromoted={(year) => onSave({ yearId: year, term: 1 })}
      />

      <div className="settings-card">
        <div className="panel-head">
          <div>
            <h3 className="panel-title">School Information</h3>
            <p className="panel-sub">Official details shown on printed result reports.</p>
          </div>
        </div>

        {schoolLoading ? (
          <div className="me-loading-panel">Loading…</div>
        ) : (
          <>
            <div className="settings-form settings-form--stack">
              <label className="settings-field">
                <span className="settings-field-label">School Name</span>
                <input className="settings-input" value={school.name} onChange={(event) => setSchool({ ...school, name: event.target.value })} placeholder="e.g. AMALI SECONDARY SCHOOL" />
              </label>
              <label className="settings-field">
                <span className="settings-field-label">District (Wilaya)</span>
                <input className="settings-input" value={school.district} onChange={(event) => setSchool({ ...school, district: event.target.value })} placeholder="e.g. KINONDONI" />
              </label>
              <label className="settings-field">
                <span className="settings-field-label">Council</span>
                <input className="settings-input" value={school.council} onChange={(event) => setSchool({ ...school, council: event.target.value })} placeholder="e.g. ILALA MUNICIPAL COUNCIL" />
              </label>
              <label className="settings-field">
                <span className="settings-field-label">Address (P.O. Box)</span>
                <input className="settings-input" value={school.address} onChange={(event) => setSchool({ ...school, address: event.target.value })} placeholder="e.g. P.O. Box 12345, DAR ES SALAAM" />
              </label>
              <div className="settings-logo-grid">
                <label className="settings-field">
                  <span className="settings-field-label">Union Logo (left)</span>
                  <input className="settings-input" type="file" accept="image/*" onChange={(event) => handleLogoChange("unionLogo", event.target.files?.[0])} />
                  {school.unionLogo && (
                    // eslint-disable-next-line @next/next/no-img-element -- user-uploaded logo, may be a data URL
                    <img className="settings-logo-preview" src={school.unionLogo} alt="Union logo preview" />
                  )}
                </label>
                <label className="settings-field">
                  <span className="settings-field-label">School Logo (right)</span>
                  <input className="settings-input" type="file" accept="image/*" onChange={(event) => handleLogoChange("schoolLogo", event.target.files?.[0])} />
                  {school.schoolLogo && (
                    // eslint-disable-next-line @next/next/no-img-element -- user-uploaded logo, may be a data URL
                    <img className="settings-logo-preview" src={school.schoolLogo} alt="School logo preview" />
                  )}
                </label>
              </div>
            </div>
            {schoolError && <p className="error-message" role="alert">{schoolError}</p>}
            <div className="settings-actions">
              <span className={`settings-status${schoolSaved ? " settings-status--ok" : ""}`}>
                {schoolSaved ? "Saved" : schoolDirty ? "Unsaved changes" : "Up to date"}
              </span>
              <button className="settings-save" onClick={handleSchoolSave} disabled={!schoolDirty}>
                {icons.check}<span>Save changes</span>
              </button>
            </div>
          </>
        )}
      </div>

      <div className="settings-card">
        <div className="panel-head">
          <div>
            <h3 className="panel-title">WhatsApp Links</h3>
            <p className="panel-sub">
              Added automatically to every results SMS sent to parents. Leave a link empty to leave that sentence out of the SMS.
            </p>
          </div>
        </div>

        {whatsappLoading ? (
          <div className="me-loading-panel">Loading…</div>
        ) : (
          <>
            <div className="settings-form settings-form--stack">
              <label className="settings-field">
                <span className="settings-field-label">Results WhatsApp Link</span>
                <input
                  className="settings-input"
                  value={whatsapp.results}
                  onChange={(event) => setWhatsapp({ ...whatsapp, results: event.target.value })}
                  placeholder="e.g. https://chat.whatsapp.com/AbCdEfGhIjK"
                />
                <span className="settings-note">SMS ends with: Tazama matokeo kamili kwenye WhatsApp: {"<link>"}</span>
              </label>
              <label className="settings-field">
                <span className="settings-field-label">Parents&rsquo; Group WhatsApp Link</span>
                <input
                  className="settings-input"
                  value={whatsapp.parentsGroup}
                  onChange={(event) => setWhatsapp({ ...whatsapp, parentsGroup: event.target.value })}
                  placeholder="e.g. https://chat.whatsapp.com/AbCdEfGhIjK"
                />
                <span className="settings-note">SMS ends with: Bonyeza link ifuatayo kujiunga na kundi la wazazi la shule: {"<link>"}</span>
              </label>
            </div>
            {whatsappError && <p className="error-message" role="alert">{whatsappError}</p>}
            <div className="settings-actions">
              <span className={`settings-status${whatsappSaved ? " settings-status--ok" : ""}`}>
                {whatsappSaved ? "Saved" : whatsappDirty ? "Unsaved changes" : "Up to date"}
              </span>
              <button className="settings-save" onClick={handleWhatsappSave} disabled={!whatsappDirty}>
                {icons.check}<span>Save changes</span>
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}